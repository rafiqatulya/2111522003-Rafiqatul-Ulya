//Soal 1
//1. isEmpty()
public class Soal1 {
    public static void main(String[] args) {
        String[] nama = { "u", "l", "", "a" };
        System.out.println(" ");
        System.out.println("Periksa apakah ArrayList kosong : ");
        System.out.println(nama[0].isEmpty());
        System.out.println(nama[1].isEmpty());
        System.out.println(nama[2].isEmpty());
        System.out.println(nama[3].isEmpty());
        System.out.println(" ");

    }
}
