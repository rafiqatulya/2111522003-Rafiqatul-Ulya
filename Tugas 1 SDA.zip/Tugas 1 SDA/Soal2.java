import java.util.ArrayList;
//Soal 2
//2. size()
public class Soal2 {
    public static void main(String[] args) 
    {
    ArrayList<String> nama = new ArrayList<String>();
    nama.add("u");
    nama.add("l");
    nama.add("y");
    nama.add("a");
    System.out.println(" ");
    System.out.println("Panjang dari array tersebut adalah : ");
    System.out.println(nama.size());
    System.out.println(" ");
    System.out.println(" ");

    }
    }