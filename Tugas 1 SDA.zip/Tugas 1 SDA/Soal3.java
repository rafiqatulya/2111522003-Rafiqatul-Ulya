import java.util.ArrayList;
//Soal 3
//3. get()
public class Soal3 {

    public static void main(String[] args) 
    {
    ArrayList<String> nama = new ArrayList<String>();
    nama.add("u");
    nama.add("l");
    nama.add("y");
    nama.add("a");
    System.out.println(" ");
    System.out.println("Elemen ke 0 = " + nama.get(0));
    System.out.println("Elemen ke 2 = " + nama.get(2));
    System.out.println("Elemen ke 6 = " + nama.get(6));
    System.out.println("Elemen ke -3) = " + nama.get(-3));
    System.out.println(" ");

    }
      
}
