import java.util.ArrayList;
//Soal 4
//4. indexOf()
public class Soal4 {
    public static void main(String[] args) 
    {
   ArrayList<String> nama = new ArrayList<String>();
   nama.add("u");
   nama.add("l");
   nama.add("y");
   nama.add("a");
   System.out.println(" ");
   System.out.println(nama.indexOf("a"));
   System.out.println(nama.indexOf("c"));
   System.out.println(nama.indexOf("q"));
   System.out.println(" ");

   }
      
}
